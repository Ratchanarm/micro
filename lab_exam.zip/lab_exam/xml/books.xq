
xquery version "3.1";

for $b in doc("library.xml")/library/book
where xs:integer($b/published) > 2020
order by $b/title ascending
return
    <book-summary id="{data($b/@id)}">
        {data($b/title)}
    </book-summary>
