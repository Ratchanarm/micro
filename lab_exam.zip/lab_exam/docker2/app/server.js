
const http = require("http");
const os = require("os");

http.createServer((req, res) => {
    res.writeHead(200, { "Content-Type": "text/plain" });
    res.end("Request handled by " + os.hostname());
}).listen(3000, "0.0.0.0", () => {
    console.log("App running on port 3000");
});
